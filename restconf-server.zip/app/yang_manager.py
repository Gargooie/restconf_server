import json
import os
from yangson import DataModel
from yangson.enumerations import ContentType
from .utils.exceptions import ValidationError, InternalServerError
from .utils.utils import load_json_file, save_json_file


class YANGManager:
    """Управляет YANG моделями и данными через yangson"""

    def __init__(self, library_file, modules_dirs, data_file):
        self.library_file = library_file
        self.modules_dirs = modules_dirs if isinstance(modules_dirs, list) else [modules_dirs]
        self.data_file = data_file
        self.data_model = None
        self.datastore = None

        # Инициализируем модель данных и хранилище
        self._init_data_model()
        self._load_datastore()

    def _init_data_model(self):
        """Инициализирует модель данных yangson"""
        try:
            self.data_model = DataModel.from_file(self.library_file, self.modules_dirs)
            print("YANG модель успешно загружена")
        except Exception as e:
            raise InternalServerError(f"Не удалось загрузить YANG модель: {e}")

    def _load_datastore(self):
        """Загружает данные из файла в хранилище"""
        try:
            raw_data = load_json_file(self.data_file)
            if raw_data:
                self.datastore = self.data_model.from_raw(raw_data)
                # Валидируем загруженные данные
                self.datastore.validate(ctype=ContentType.all)
                print("Данные успешно загружены и валидированы")
            else:
                # Создаем пустое хранилище
                self.datastore = self.data_model.from_raw({})
        except Exception as e:
            raise InternalServerError(f"Не удалось загрузить данные: {e}")

    def get_data(self, resource_path=""):
        """Получает данные по указанному пути"""
        try:
            if not resource_path:
                # Возвращаем все данные
                return self.datastore.raw_value()

            # Парсим путь ресурса
            try:
                irt = self.data_model.parse_resource_id(resource_path)
                data_instance = self.datastore.goto(irt)
                return data_instance.raw_value()
            except Exception:
                # Если путь не найден, возвращаем None
                return None

        except Exception as e:
            raise InternalServerError(f"Ошибка при получении данных: {e}")

    def update_data(self, resource_path, data):
        """Обновляет данные по указанному пути (PATCH операция)"""
        try:
            # Создаем копию для валидации
            test_datastore = self.datastore

            if resource_path:
                # Обновляем конкретный путь
                irt = self.data_model.parse_resource_id(resource_path)

                # Находим узел для обновления
                try:
                    target_node = test_datastore.goto(irt)
                    # Обновляем узел с новыми данными
                    updated_node = target_node.update(data)
                    test_datastore = updated_node.top()
                except Exception:
                    # Если узел не существует, создаем его
                    # Это упрощенная логика, в реальности нужна более сложная обработка
                    test_datastore = self._merge_data(test_datastore, resource_path, data)
            else:
                # Обновляем корень
                raw_data = test_datastore.raw_value()
                raw_data.update(data)
                test_datastore = self.data_model.from_raw(raw_data)

            # Валидируем обновленные данные
            test_datastore.validate(ctype=ContentType.config)

            # Если валидация прошла, применяем изменения
            self.datastore = test_datastore

            # Сохраняем в файл
            self._save_datastore()

            return True

        except Exception as e:
            raise ValidationError(f"Ошибка валидации: {e}")

    def _merge_data(self, datastore, path, data):
        """Вспомогательный метод для слияния данных"""
        # Упрощенная логика слияния
        raw_data = datastore.raw_value()

        # Это базовая реализация, в реальности нужна более сложная логика
        # для правильного слияния данных по пути
        if isinstance(data, dict):
            for key, value in data.items():
                raw_data[key] = value

        return self.data_model.from_raw(raw_data)

    def _save_datastore(self):
        """Сохраняет хранилище в файл"""
        try:
            save_json_file(self.datastore.raw_value(), self.data_file)
        except Exception as e:
            raise InternalServerError(f"Не удалось сохранить данные: {e}")

    def validate_data(self, data):
        """Валидирует данные против схемы"""
        try:
            instance = self.data_model.from_raw(data)
            instance.validate(ctype=ContentType.config)
            return True
        except Exception as e:
            raise ValidationError(f"Данные не прошли валидацию: {e}")
